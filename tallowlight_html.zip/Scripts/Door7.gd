extends Area2D

@onready var collision_shape_2d = $CollisionShape2D
@onready var game_manager_level_7 = $"../GameManagerLevel7"
@onready var open = $Open
@onready var close = $Close
@onready var sprite_2d = $Sprite2D
var canEnter = false

func _process(delta):
	if game_manager_level_7.allTorchLit:
		open.visible = true
		close.visible = false
		collision_shape_2d.disabled = false
	if Input.is_action_just_pressed("Enter") and canEnter:
		print("you have entered")
		call_deferred("_change_scene")

func _on_body_entered(body):
	print("you are in")
	sprite_2d.visible = true
	canEnter = true
		
func _on_body_exited(body):
	print("you are out")
	sprite_2d.visible = false
	canEnter = false

func _change_scene():
	get_tree().change_scene_to_file("res://Scene/level8.tscn")
